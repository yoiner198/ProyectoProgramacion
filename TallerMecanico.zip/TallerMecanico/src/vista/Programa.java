package vista;

import java.util.Scanner;
import modelo.*;

public class Programa {

    public static void main(String[] args) {

        //Variables para el desarrollo del programa
        Taller taller = new Taller();
        Trabajador trabajador;
        Coche coche;
        byte opcion = 0;
        char tipoCoche = 'A';
        String fecha;
        Scanner sc = new Scanner(System.in);

        do {

            System.out.println("\nTALLER MECANICO");

            System.out.println("\n1. Registrar coche entrante");
            System.out.println("2. Registrar un nuevo trabajador");
            System.out.println("3. Lista de trabajadores");
            System.out.println("4. Lista de coches atendidos segun la fecha");
            System.out.println("5. Cantidad de dinero recuaudada segun la fecha");
            System.out.println("6. Salir");

            System.out.print("\nDigite una opción (1-6) -> ");
            opcion = sc.nextByte();

            while (opcion > 6 || opcion < 1) {
                System.out.print("\nOpción invalida intente nuevamente -> ");
                opcion = sc.nextByte();
            }
            sc.nextLine();

            switch (opcion) {
                case 1:

                    if (!taller.getTrabajadores().isEmpty()) {
                        System.out.println("\nDigite el tipo de coche a atender");

                        System.out.println("\nA. Coche familiar");
                        System.out.println("B. Coche de carreras");
                        System.out.println("C. Camion");

                        System.out.print("\nDigite una opción (A-C) -> ");
                        tipoCoche = sc.next().toUpperCase().charAt(0);
                        sc.nextLine();

                        System.out.print("\nDigite la marca del coche: ");
                        String marca = sc.nextLine();
                        System.out.print("Digite la matricula del coche: ");
                        String matricula = sc.nextLine();
                        System.out.print("Digite el estado del aceite (bueno, reemplazar): ");
                        String aceite = sc.nextLine();
                        System.out.print("Problema encontrado (llantas, cilindraje, pintar): ");
                        String problema = sc.nextLine().toLowerCase();

                        System.out.print("Trabajador encargado: ");
                        String nombre = sc.nextLine();
                        Trabajador trabajadorEncargado = taller.buscarTrabajador(nombre);

                        //Verificar que el trabajador exista
                        while (trabajadorEncargado == null) {
                            System.out.print("\nTrabajador no encontrado, intente nuevamente: ");
                            nombre = sc.nextLine();
                            trabajadorEncargado = taller.buscarTrabajador(nombre);
                        }

                        //Verificar que un trabajador este capacitado para la tarea del motor
                        Object clase = trabajadorEncargado.getClass();
                        while (trabajadorEncargado.getClass() == clase && tipoCoche == 'B') {
                            System.out.print("\nTrabajador no capacitado para dicha tarea, asigne a otro: ");
                            nombre = sc.nextLine();
                            trabajadorEncargado = taller.buscarTrabajador(nombre);
                        }

                        System.out.print("Fecha de ingreso (dd/mm/aaaa): ");
                        String fechaReparacion = sc.nextLine();

                        if (tipoCoche == 'A') {

                            System.out.print("Dueño del coche: ");
                            String poseedor = sc.nextLine();
                            System.out.print("Año de compra: ");
                            short yearCompra = sc.nextShort();
                            sc.nextLine();
                            coche = new Familiar(marca, matricula, aceite,
                                    poseedor, problema, trabajadorEncargado, fechaReparacion, yearCompra);

                        } else if (tipoCoche == 'B') {
                            System.out.print("Agencia del coche: ");
                            String agencia = sc.nextLine();
                            System.out.print("Estado del motor (estable, riesgo o dañado): ");
                            String motor = sc.nextLine();

                            coche = new Carrera(marca, matricula, aceite, agencia,
                                    problema, trabajadorEncargado, fechaReparacion, motor);
                        } else {

                            System.out.print("Empresa: ");
                            String empresa = sc.nextLine();
                            System.out.print("Cantidad de mercancia transportada: ");
                            int mercancia = sc.nextInt();
                            sc.nextLine();

                            coche = new Camion(marca, matricula, aceite, empresa,
                                    problema, trabajadorEncargado, fechaReparacion, mercancia);
                        }
                        taller.agregarCoche(coche);
                        System.out.println("\nCoche registrado en el taller con exito");

                    } else {
                        System.out.println("\nNo hay trabajadores en su taller");
                        System.out.println("Registre alguno para que pueda trabajar en un coche");
                    }
                    break;

                case 2:

                    System.out.print("\nCedula: ");
                    String cedula = sc.nextLine();
                    System.out.print("Nombre del trabajador: ");
                    String nombre = sc.nextLine();
                    System.out.print("Fecha de nacimiento: ");
                    String fechaNacimiento = sc.nextLine();

                    System.out.print("\nEs un trabajador especializado (S/N): ");
                    char decision = sc.next().toUpperCase().charAt(0);
                    sc.nextLine();

                    if (decision == 'S') {

                        System.out.print("\nEspecializacion (Cambio pistones, "
                                + "Enfriamiento líquido, Cambio de bujías): ");
                        String especializacion = sc.nextLine();

                        trabajador = new TrabajadorEspecializado(cedula, nombre, fechaNacimiento, especializacion);

                    } else {
                        trabajador = new Trabajador(cedula, nombre, fechaNacimiento);
                    }

                    if (taller.buscarTrabajador(cedula) != null) {
                        System.out.println("No se puede añadir al trabajador, cédula registrada");
                    } else {
                        taller.agregarTrabajador(trabajador);
                        System.out.println("\nTrabajador registrado en el taller con exito");
                    }
                    break;

                case 3:

                    if (taller.getTrabajadores().isEmpty()) {
                        System.out.println("\nSin trabajadores a mostrar");
                    } else {
                        System.out.println("\n\tLISTA DE TRABAJADORES\n");
                        System.out.println("--------------------*--------------------");
                        for (Trabajador tbj : taller.getTrabajadores()) {
                            tbj.imprimirDatos();
                            System.out.println("--------------------*--------------------");
                        }
                    }
                    break;

                case 4:
                    System.out.print("\nFecha a conocer los coches atendidos (dd/mm/aaaa): ");
                    fecha = sc.nextLine();

                    if (taller.getCoches(fecha).isEmpty()) {
                        System.out.println("\nSin coches registrados en esa fecha");
                    } else {
                        System.out.printf("\n\tLISTA DE COCHES ATENDIDOS EL %s\n\n", fecha);
                        System.out.println("--------------------*--------------------");
                        for (Coche ch : taller.getCoches(fecha)) {
                            ch.imprimirDatos();
                            System.out.println("--------------------*--------------------");
                        }
                    }
                    break;

                case 5:

                    System.out.print("\nDigite la fecha a conocer el total recaudado (dd/mm/aaaa): ");
                    fecha = sc.nextLine();

                    if (taller.getFactura(fecha) == 0) {
                        System.out.println("\nNo se atendieron autos en esa fecha");

                    } else {
                        System.out.println("\nEl dinero total recaudado en la fecha del " + fecha
                                + " es de " + taller.getFactura(fecha));
                    }
                    break;
                default:
                    System.out.println("\nHasta la proxima");
            }

            if (opcion != 6) {
                System.out.print("\nPresione Enter para continuar ");
                sc.nextLine();
            }
        } while (opcion != 6);
    }
}
