package modelo;

public abstract class Coche {

    private String marca, matricula, aceite;
    private String poseedor;
    private String problema;
    private Trabajador trabajadorEncargado;
    private String fechaReparacion;
    private double costoReparacion;

    public Coche() {
    }

    public Coche(String marca, String matricula, String aceite, String poseedor, 
            String problema, Trabajador trabajadorEncargado, String fechaReparacion) {
        this.marca = marca;
        this.matricula = matricula;
        this.aceite = aceite;
        this.poseedor = poseedor;
        this.problema = problema;
        this.trabajadorEncargado = trabajadorEncargado;
        this.fechaReparacion = fechaReparacion;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getAceite() {
        return aceite;
    }

    public void setAceite(String aceite) {
        this.aceite = aceite;
    }

    public String getPoseedor() {
        return poseedor;
    }

    public void setPoseedor(String poseedor) {
        this.poseedor = poseedor;
    }

    public String getProblema() {
        return problema;
    }

    public void setProblema(String problema) {
        this.problema = problema;
    }
     
    public double getCostoReparacion() {
        
        return this.costoReparacion;
    }

    public Trabajador getTrabajadorEncargado() {
        return trabajadorEncargado;
    }

    public void setTrabajadorEncargado(Trabajador trabajadorEncargado) {
        this.trabajadorEncargado = trabajadorEncargado;
    }

    public String getFechaReparacion() {
        return fechaReparacion;
    }

    public void setFechaReparacion(String fechaReparacion) {
        this.fechaReparacion = fechaReparacion;
    }
    
    public void setCostoReparacion(){
        
        switch (this.problema) {
            case "llantas":
                this.costoReparacion = 4;
                break;
            case "cilindraje":
                this.costoReparacion = 700;
                break;
            default:
                this.costoReparacion = 200;
                break;
        }
    }
    
    public void imprimirDatos() {
        System.out.println("Marca: "+ this.marca);
        System.out.println("Matricula: "+ this.matricula);
        System.out.println("Problema: " + this.problema);
        System.out.println("Trabajador encargado: " + this.trabajadorEncargado.getNombre());
        System.out.println("Fecha de reparacion: " + this.fechaReparacion);
        System.out.println("Costo de la reparación: " + this.costoReparacion);
    }
}
