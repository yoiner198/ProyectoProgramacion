package modelo;

public class Familiar extends Coche{
    
    private short yearCompra;

    public Familiar() {
    }

    public Familiar(String marca, String matricula, String aceite, String poseedor, 
            String problema, Trabajador trabajadorEncargado, String fechaReparacion, short yearCompra) {
        super(marca, matricula, aceite, poseedor, problema, trabajadorEncargado, fechaReparacion);
        this.yearCompra = yearCompra;
    }

    public short getYearCompra() {
        return yearCompra;
    }

    public void setYearCompra(short yearCompra) {
        this.yearCompra = yearCompra;
    }
    
    @Override
    public void imprimirDatos() {
        super.imprimirDatos();
        System.out.println("Dueño: " + this.getPoseedor());
        System.out.println("Año de compra: " + this.yearCompra);
    }
}
