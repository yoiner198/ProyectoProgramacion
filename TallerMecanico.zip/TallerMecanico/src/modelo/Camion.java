package modelo;

public class Camion extends Coche{
    private int mercancia;

    public Camion() {
    }

    public Camion(String marca, String matricula, String aceite, String poseedor, 
            String problema, Trabajador trabajadorEncargado, String fechaReparacion, int cantMercancia) {
        super(marca, matricula, aceite, poseedor, problema, trabajadorEncargado, fechaReparacion);
        this.mercancia = cantMercancia;
    }

    public int getMercancia() {
        return mercancia;
    }

    public void setMercancia(int mercancia) {
        this.mercancia = mercancia;
    }
    
    @Override
    public void imprimirDatos() {
        super.imprimirDatos();
        System.out.println("Empresa: " + this.getPoseedor());
        System.out.println("Cantidad de la mercancia: "
                + "el día de ingreso al taller: " + this.mercancia);
    }
}
