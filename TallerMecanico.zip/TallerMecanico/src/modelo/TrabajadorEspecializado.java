package modelo;

public class TrabajadorEspecializado extends Trabajador {

    private String especializacion;

    public TrabajadorEspecializado() {
    }

    public TrabajadorEspecializado( String cedula, String nombre, String fechaNacimiento, String especializacion) {
        super(cedula, nombre, fechaNacimiento);
        this.especializacion = especializacion;
    }

    public String getEspecializacion() {
        return especializacion;
    }

    public void setEspecializacion(String especializacion) {
        this.especializacion = especializacion;
    }

    @Override
    public void imprimirDatos() {
        super.imprimirDatos();
        System.out.println("Especializacion: "+ this.especializacion);
    }
}
