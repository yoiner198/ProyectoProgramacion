package modelo;

public class Carrera extends Coche{

    private String motor;

    public Carrera() {
    }

    public Carrera(String marca, String matricula, String aceite, String poseedor, 
            String problema, Trabajador trabajadorEncargado, String fechaReparacion, String motor) {
        super(marca, matricula, aceite, poseedor, problema, trabajadorEncargado, fechaReparacion);
        this.motor = motor;
    }

    public String getMotor() {
        return motor;
    }

    public void setMotor(String motor) {
        this.motor = motor;
    }
    
    @Override
    public double getCostoReparacion() {
        if(this.motor.equals("dañado")){
            return super.getCostoReparacion() + 10000;
            
        }else{
            return super.getCostoReparacion();
        }
    }
    
    @Override
    public void imprimirDatos() {
        super.imprimirDatos();
        System.out.println("Agencia: " + this.getPoseedor());
        System.out.println("Estado del motor el día de la reparación: " + this.motor);
    }
}
